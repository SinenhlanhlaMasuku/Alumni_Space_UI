import { Component } from '@angular/core';

@Component({
  selector: 'app-people-you-may-know',
  templateUrl: './people-you-may-know.component.html',
  styleUrls: ['./people-you-may-know.component.css']
})
export class PeopleYouMayKnowComponent {

}
