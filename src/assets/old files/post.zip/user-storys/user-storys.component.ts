import { Component } from '@angular/core';

@Component({
  selector: 'app-user-storys',
  templateUrl: './user-storys.component.html',
  styleUrls: ['./user-storys.component.css']
})
export class UserStorysComponent {

}
